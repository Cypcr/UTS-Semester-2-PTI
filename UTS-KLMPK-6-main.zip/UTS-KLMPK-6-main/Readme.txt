Kelompok 6
IF231-C

1.Daffa Dwi Haykal (00000057951)
2.Edgar Jordan Umbu Raya Tabungo (00000059079)
3.Gilbert Valerio Tanriono (00000058389)
4.Yolanda Mere Marie (00000059051)

#Peraturan Permainan

+Pemain akan di sediakan pemilhan avatar, dan juga memasukkan nama.

+Setelah itu pemain akan menekan tombol "Play" dan menuju laman permainan.

+Disini terdapat 4 bar status karakter, yang terdiri dari :
    -Makan
    -Tidur
    -Main
    -Belajar
    (Setiap barnya akan dimulai dari 50 dan berkurang seiring waktu, kecuali belajar)
    Setiap barnya berisi 100.

+Terdapat indikator uang dalam satuan dollar, yang akan berperan dalam jalannya permainan.

+Setiap melakukan suatu aktivitas, maka akan mengurangi setidaknya satu nilai dari bar aktivitas lainnya.

+Apabila bar "Makan" mencapai nilai 0, maka akan muncul peringatan,dan tidak dapat melakukan aktivitas makan,
 tetapi pemain dapat melakukan pembelian item "Chicken Nuget" seharga $150 untuk menghidupkan kembali bar Makan.

+Apabila bar "Tidur" mencapai nilai 0, maka akan muncul peringatan,dan tidak dapat melakukan aktivitas Tidur,
 tetapi pemain dapat melakukan pembelian item "Medicine" seharga $200 untuk menghidupkan kembali bar Tidur.

+Apabila bar "Main" mencapai nilai 0, maka akan muncul peringatan,dan tidak dapat melakukan aktivitas main,
 tetapi pemain dapat melakukan pembelian item "Anti Depressant" seharga $150 untuk menghidupkan kembali bar Main.

+Lalu pemain dapat melakukan pembelian item atribut "Almamater" seharga $250, dan menyebabkan efek penambahan uang yang jauh lebih cepat.

+Dan untuk menyelesaikan game ini, pemain diharuskan mengambil item "WISUDA" dengan syarat telah melalui 8 Semester.

+Jumlah semester sakan didapat seiringnya pertumbuhan bar Belajar ketika mencapai nilai 100.

+Dan tidak lupa karakter akan Gameover ketika bar status (Makan,Tidur,Main) berada dititik 0.